
-- 文件表增加排序字段
ALTER TABLE ${_prefix}sys_file_upload ADD file_sort decimal(10) NULL;
